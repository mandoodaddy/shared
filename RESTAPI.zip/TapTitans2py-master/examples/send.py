import socket
import json

# 소켓 서버의 호스트와 포트
HOST = 'https://mandoo-bot-02d4684c3596.herokuapp.com/'
PORT = 5000

def start_client():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
        try:
            client.connect((HOST, PORT))
            print('Connected to {}:{}'.format(HOST, PORT))

            while True:
                message = input('Enter a message to send (or type "exit" to quit): ')
                if message == 'exit':
                    break

                client.sendall(message.encode())
                response = client.recv(1024)
                print('Server response:', response.decode())

        except Exception as e:
            print('Error occurred:', str(e))

start_client()
'''
js1 = "{'attack_log': {'attack_datetime': '2023-07-03T13:56:27Z', 'cards_damage': [{'titan_index': 4, 'id': 'None', 'damage_log': [{'id': 'ArmorHandLeft', 'value': 2287276}, {'id': 'ArmorArmUpperLeft', 'value': 2614030}, {'id': 'ArmorHead', 'value': 2744731}, {'id': 'ArmorArmUpperRight', 'value': 941051}, {'id': 'ArmorChestUpper', 'value': 13071}, {'id': 'BodyArmUpperRight', 'value': 12487}]}, {'titan_index': 4, 'id': 'SuperheatMetal', 'damage_log': []}, {'titan_index': 4, 'id': 'Disease', 'damage_log': [{'id': 'ArmorHandLeft', 'value': 8460237}, {'id': 'ArmorArmUpperLeft', 'value': 9991882}, {'id': 'ArmorHead', 'value': 8300438}, {'id': 'ArmorArmUpperRight', 'value': 1919850}, {'id': 'BodyArmUpperRight', 'value': 573449}]}, {'titan_index': 4, 'id': 'TeamTactics', 'damage_log': []}], 'cards_level': [{'id': 'Disease', 'value': 41}, {'id': 'SuperheatMetal', 'value': 34}, {'id': 'TeamTactics', 'value': 32}]}, 'clan_code': 'v8mx9', 'raid_id': 2860071, 'player': {'attacks_remaining': 3, 'player_code': 'bnbpyd7', 'name': 'ShinBBing', 'raid_level': 903}, 'raid_state': {'current': {'enemy_id': 'Enemy8', 'current_hp': 7589413916.0, 'parts': [{'part_id': 'BodyHead', 'current_hp': 3870900000.0}, {'part_id': 'ArmorHead', 'current_hp': 2130475441.0}, {'part_id': 'BodyChestUpper', 'current_hp': 1935450000.0}, {'part_id': 'ArmorChestUpper', 'current_hp': 1880609450.0}, {'part_id': 'BodyArmUpperRight', 'current_hp': 967139065.0}, {'part_id': 'ArmorArmUpperRight', 'current_hp': 0.0}, {'part_id': 'BodyArmUpperLeft', 'current_hp': 967725000.0}, {'part_id': 'ArmorArmUpperLeft', 'current_hp': 158837904.0}, {'part_id': 'BodyLegUpperRight', 'current_hp': 379500000.0}, {'part_id': 'ArmorLegUpperRight', 'current_hp': 1129272323.0}, {'part_id': 'BodyLegUpperLeft', 'current_hp': 379500000.0}, {'part_id': 'ArmorLegUpperLeft', 'current_hp': 1132227688.0}, {'part_id': 'BodyHandRight', 'current_hp': 967725000.0}, {'part_id': 'ArmorHandRight', 'current_hp': 203090441.0}, {'part_id': 'BodyHandLeft', 'current_hp': 967725000.0}, {'part_id': 'ArmorHandLeft', 'current_hp': 228212220.0}]}, 'titan_index': 4}}"
js1 = js1.replace("'", '"')
jsonObject = json.loads(js1)


print(jsonObject.get('player').get('name')+'('+str(jsonObject.get('player').get('raid_level'))+') 남은타수:'+str(jsonObject.get('player').get('attacks_remaining')))
print('카드 : ' + jsonObject.get('attack_log').get('cards_level')[0].get('id') + '('+str(jsonObject.get('attack_log').get('cards_level')[0].get('value'))+'),')
'''