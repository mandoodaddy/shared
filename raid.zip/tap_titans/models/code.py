class Code(str):
    pass


class PlayerCode(Code):
    pass


class ClanCode(Code):
    pass
